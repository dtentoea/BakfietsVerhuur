﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fietsverhuur
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        //  Feedback: 
        // - Method: prijzen als parameters meegegven.   
        // - Array gebruikt in de verkoop op alle producten 


        // Variabelen
        private decimal fiets1;
        private decimal fiets2;
        private decimal fiets3;
        private decimal fiets4;

        private decimal accHelm1;
        private decimal accHelm2;
        private decimal accHelm3;

        private decimal fietsacc1;
        private decimal fietsacc2;
        private decimal fietsacc3;

        private decimal accextr1;
        private decimal accextr2;

        //Method Prijs Berekening
        decimal Totaleprijs(decimal n1, decimal n2, decimal n3, decimal n4, decimal n5, decimal n6, decimal n7, decimal n8, decimal n9, decimal n10, decimal n11, decimal n12)
        {
            decimal total = n1 + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10 + n11 + n12;
            return total;
        }
    

        #region Tab 2
        // Tab2 Fietsen 
        private void btnFietsklaar_Click(object sender, EventArgs e)
        {
            //Show in Overzicht Listbox  + avoid doubles 
            decimal[] fietsen = new decimal[4];
            fietsen[0] = 60;
            fietsen[1] = 110;
            fietsen[2] = 90;
            fietsen[3] = 30;

            // verkoop fietsen     <---  FEEDBACK prijzen in een array zetten 
            fiets1 = chkFiets1.Checked ? nudFiets1aantal.Value * nudFiets1dagen.Value * fietsen[0] : 0;
            fiets2 = chkFiets2.Checked ? nudFiets2aantal.Value * nudFiets2dagen.Value * fietsen[1] : 0;
            fiets3 = chkFiets3.Checked ? nudFiets3aantal.Value * nudFiets3dagen.Value * fietsen[2] : 0;
            fiets4 = chkFiets4.Checked ? nudFiets4aantal.Value * nudFiets4dagen.Value * fietsen[3] : 0;

            // Show in UI
            lblFietsentotaleprijs.Text = Convert.ToString("Totale Prijs: " + Totaleprijs(fiets1,fiets2,fiets3,fiets4,accHelm1,accHelm2,accHelm3,fietsacc1,fietsacc2,fietsacc3,accextr1,accextr2) + ",-") ;
            lbBetalenTotaleprijs.Text = Convert.ToString("Totale Prijs: " + Totaleprijs(fiets1, fiets2, fiets3, fiets4, accHelm1, accHelm2, accHelm3, fietsacc1, fietsacc2, fietsacc3, accextr1, accextr2) + ",-");
            lbTotPrijsAcc.Text = Convert.ToString("Totale Prijs: " + Totaleprijs(fiets1, fiets2, fiets3, fiets4, accHelm1, accHelm2, accHelm3, fietsacc1, fietsacc2, fietsacc3, accextr1, accextr2) + ",-");

            //Show in Overzicht Listbox  + avoid doubles 

            decimal j = nudFiets1aantal.Value;
            decimal k = nudFiets2aantal.Value;
            decimal x = nudFiets3aantal.Value;
            decimal y = nudFiets4aantal.Value;

            if (chkFiets1.Checked)
            {
                for (decimal i = 0; i < j; i = i + 1)
                {
                    lstOverzicht.Items.Add("1. Bamboo BF Standaard: " + "Prijs: " + fietsen[0] + "  Dagen: " + nudFiets1dagen.Value);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }
            if (chkFiets2.Checked)
            {
                for (decimal i = 0; i < k; i = i + 1)
                {
                    lstOverzicht.Items.Add("2. Bamboo BF DELUXE:   " + "Prijs: " + fietsen[1] + "  Dagen: " + nudFiets2dagen.Value);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }
            if (chkFiets3.Checked)
            {
                for (decimal i = 0; i < x; i = i + 1)
                {
                    lstOverzicht.Items.Add("3. Bamboo BF Cruiser:   " + "Prijs: " + fietsen[2] + "  Dagen: " + nudFiets3dagen.Value);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }
            if (chkFiets4.Checked)
            {
                for (decimal i = 0; i < y; i = i + 1)
                {
                    lstOverzicht.Items.Add("4. Bamboo BeFun:        " + "Prijs: " + fietsen[3] + "  Dagen: " + nudFiets4dagen.Value);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }



        }

        private void btnT2volgende_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }
        #endregion

        #region Tab 3
        // Tab 3 Accessoires    <---- FEEDBACK  prijzen in een array zetten 
        private void btnAccKlaar_Click(object sender, EventArgs e)
        {
            decimal[] accessoires = new decimal[3];
            accessoires[0] = 20;
            accessoires[1] = 15;
            accessoires[2] = 1;


            //Verkoop Helmen 
            accHelm1 = chbBesHelmS.Checked ? nudHelmS.Value * accessoires[0] : 0;
            accHelm2 = chbBesHelmM.Checked ? nudHelmM.Value * accessoires[0] : 0;
            accHelm3 = chbBesHelmL.Checked ? nudHelmL.Value * accessoires[0] : 0;

            //Verkoop Acc
            fietsacc1 = chbAcc1.Checked ? nudAcc1.Value * accessoires[1] : 0;
            fietsacc2 = chbAcc2.Checked ? nudAcc2.Value * accessoires[1] : 0;
            fietsacc3 = chbAcc3.Checked ? nudAcc3.Value * accessoires[1] : 0;

            //Verkoop Extra's
            accextr1 = chbExtr1.Checked ? nudExtr1.Value * accessoires[2] : 0;
            accextr2 = chbExtr2.Checked ? nudExtr2.Value * accessoires[2] : 0;

            // Show in UI
            lblFietsentotaleprijs.Text = Convert.ToString("Totale Prijs: " + Totaleprijs(fiets1, fiets2, fiets3, fiets4, accHelm1, accHelm2, accHelm3, fietsacc1, fietsacc2, fietsacc3, accextr1, accextr2) + ",-");
            lbBetalenTotaleprijs.Text = Convert.ToString("Totale Prijs: " + Totaleprijs(fiets1, fiets2, fiets3, fiets4, accHelm1, accHelm2, accHelm3, fietsacc1, fietsacc2, fietsacc3, accextr1, accextr2) + ",-");
            lbTotPrijsAcc.Text = Convert.ToString("Totale Prijs: " + Totaleprijs(fiets1, fiets2, fiets3, fiets4, accHelm1, accHelm2, accHelm3, fietsacc1, fietsacc2, fietsacc3, accextr1, accextr2) + ",-");

            //Show in Overzicht Listbox  + avoid doubles 

            decimal j = nudHelmS.Value;
            decimal k = nudHelmM.Value;
            decimal l = nudHelmL.Value;

            decimal x = nudAcc1.Value;
            decimal y = nudAcc2.Value;
            decimal z = nudAcc3.Value;

            decimal a = nudExtr1.Value;
            decimal b = nudExtr2.Value;


            //Helm
            if (chbBesHelmS.Checked)
            {
                for (decimal i = 0; i < j; i = i + 1)
                {
                    lstOverzicht.Items.Add("Helm S:        " + "Prijs: " + accessoires[0]);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }
            if (chbBesHelmM.Checked)
            {
                for (decimal i = 0; i < k;  i = i + 1)
                {
                    lstOverzicht.Items.Add("Helm M:        " + "Prijs: " + accessoires[0]);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }
            if (chbBesHelmL.Checked)
            {
                for (decimal i = 0; i < l;  i = i + 1)
                {
                    lstOverzicht.Items.Add("Helm L:        " + "Prijs: " + accessoires[0]);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }

            //Acc
            if (chbAcc1.Checked)
            {
                for (decimal i = 0; i < x; i = i + 1)
                {
                    lstOverzicht.Items.Add("Zonnescherm:        " + "Prijs: " + accessoires[1]);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                } 
            }
            if (chbAcc2.Checked)
            {
                for (decimal i = 0; i < y; i = i + 1)
                {
                    lstOverzicht.Items.Add("Telefoonhouder:        " + "Prijs: " + accessoires[1]);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                } 
            }
            if (chbAcc3.Checked)
            {
                for (decimal i = 0; i < z; i = i + 1)
                {
                    lstOverzicht.Items.Add("Speaker:        " + "Prijs: " + accessoires[1]);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }

            //Extra
            if (chbExtr1.Checked)
            {
                for (decimal i = 0; i < a; i = i + 1)
                {
                    lstOverzicht.Items.Add("Zonnescherm:        " + "Prijs: " + accessoires[2]);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }
            if (chbExtr2.Checked)
            {
                for (decimal i = 0; i < b; i = i + 1)
                {
                    lstOverzicht.Items.Add("Zonnescherm:        " + "Prijs: " + accessoires[2]);
                    lstOverzicht.Items.Add("---------------------------------------------------------------------------------------");
                }
            }


        }

        private void btnT3Vorige_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void btnT3Volgende_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }
        #endregion

        #region Tab 4
        //Tab 4 Betalen
        private void btnT4Terug_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
            lstOverzicht.Items.Clear();
            lblFietsentotaleprijs.Text = Convert.ToString("Totale Prijs: " + 0 + ",-");
            lbBetalenTotaleprijs.Text = Convert.ToString("Totale Prijs: " + 0 + ",-");
            lbTotPrijsAcc.Text = Convert.ToString("Totale Prijs: " + 0 + ",-");
        }

        // Betaalbuttons 
        private void btnBetalen_Click(object sender, EventArgs e)
        {
            if (rdoContant.Checked)
            {
                MessageBox.Show("System error. Tax evasion detected");
                MessageBox.Show("System error. Tax evasion detected");
                MessageBox.Show("System error. Tax evasion detected");
            }
            if (rdoIDeal.Checked || rdoKlerna.Checked || rdoVisa.Checked)
            {
                MessageBox.Show("Wegens problemen met de belasting, graag een andere optie kiezen.                                            Dankuwel voor uw begrip");
            }
        }
        // Kortings code toevoegen 
        private void btnKortingtoevoegen_Click(object sender, EventArgs e)
        {
            string Text = "kortingscodefontys";
            if (tbKortingscode.Text.Contains(Text))
            {
                decimal nieuweprijs;
                nieuweprijs = (Totaleprijs(fiets1, fiets2, fiets3, fiets4, accHelm1, accHelm2, accHelm3, fietsacc1, fietsacc2, fietsacc3, accextr1, accextr2) / 100) * 70;

                lblFietsentotaleprijs.Text = Convert.ToString("Totale Prijs: " + nieuweprijs + ",-");
                lbBetalenTotaleprijs.Text = Convert.ToString("Totale Prijs: " + nieuweprijs + ",-");
                lbTotPrijsAcc.Text = Convert.ToString("Totale Prijs: " + nieuweprijs + ",-");
                tbKortingscode.Enabled = false;
                tbKortingscode.Text = "Één korting is genoeg. Bedankt.";
            }
            else
            {
                MessageBox.Show("Deze code is niet geldig");
            }
        }

        private void btT1Begin_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }
    }
    #endregion
}
