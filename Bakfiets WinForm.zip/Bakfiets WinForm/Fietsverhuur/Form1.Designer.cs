﻿
namespace Fietsverhuur
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btT1Begin = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.btnFietsklaar = new System.Windows.Forms.Button();
            this.lblFietsentotaleprijs = new System.Windows.Forms.Label();
            this.btnT2volgende = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.nudFiets4aantal = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nudFiets4dagen = new System.Windows.Forms.NumericUpDown();
            this.chkFiets4 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.nudFiets2aantal = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nudFiets2dagen = new System.Windows.Forms.NumericUpDown();
            this.chkFiets2 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.nudFiets3aantal = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.nudFiets3dagen = new System.Windows.Forms.NumericUpDown();
            this.chkFiets3 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nudFiets1aantal = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nudFiets1dagen = new System.Windows.Forms.NumericUpDown();
            this.chkFiets1 = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label16 = new System.Windows.Forms.Label();
            this.lbTotPrijsAcc = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAccKlaar = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.chbExtr2 = new System.Windows.Forms.CheckBox();
            this.nudExtr2 = new System.Windows.Forms.NumericUpDown();
            this.chbExtr1 = new System.Windows.Forms.CheckBox();
            this.nudExtr1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.nudAcc3 = new System.Windows.Forms.NumericUpDown();
            this.chbAcc2 = new System.Windows.Forms.CheckBox();
            this.nudAcc2 = new System.Windows.Forms.NumericUpDown();
            this.chbAcc1 = new System.Windows.Forms.CheckBox();
            this.nudAcc1 = new System.Windows.Forms.NumericUpDown();
            this.chbAcc3 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.nudHelmL = new System.Windows.Forms.NumericUpDown();
            this.nudHelmM = new System.Windows.Forms.NumericUpDown();
            this.nudHelmS = new System.Windows.Forms.NumericUpDown();
            this.chbBesHelmM = new System.Windows.Forms.CheckBox();
            this.chbBesHelmL = new System.Windows.Forms.CheckBox();
            this.chbBesHelmS = new System.Windows.Forms.CheckBox();
            this.btnT3Volgende = new System.Windows.Forms.Button();
            this.btnT3Vorige = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lstOverzicht = new System.Windows.Forms.ListBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btnKortingtoevoegen = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.rdoKlerna = new System.Windows.Forms.RadioButton();
            this.rdoVisa = new System.Windows.Forms.RadioButton();
            this.rdoContant = new System.Windows.Forms.RadioButton();
            this.rdoIDeal = new System.Windows.Forms.RadioButton();
            this.btnBetalen = new System.Windows.Forms.Button();
            this.btnT4Terug = new System.Windows.Forms.Button();
            this.lbBetalenTotaleprijs = new System.Windows.Forms.Label();
            this.tbKortingscode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets4aantal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets4dagen)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets2aantal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets2dagen)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets3aantal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets3dagen)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets1aantal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets1dagen)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudExtr2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudExtr1)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAcc3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAcc2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAcc1)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudHelmL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHelmM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHelmS)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(7, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(457, 461);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btT1Begin);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(449, 435);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Home";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btT1Begin
            // 
            this.btT1Begin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.btT1Begin.Location = new System.Drawing.Point(46, 358);
            this.btT1Begin.Name = "btT1Begin";
            this.btT1Begin.Size = new System.Drawing.Size(361, 33);
            this.btT1Begin.TabIndex = 2;
            this.btT1Begin.Text = "Begin met bestellen!";
            this.btT1Begin.UseVisualStyleBackColor = true;
            this.btT1Begin.Click += new System.EventHandler(this.btT1Begin_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(86, 65);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(255, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "De speciaalzaak voor al uw bakfiets benodigheden. ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label22.Location = new System.Drawing.Point(41, 39);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(365, 26);
            this.label22.TabIndex = 0;
            this.label22.Text = "Welkom bij Bamboo BakFietsen! ";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.btnFietsklaar);
            this.tabPage2.Controls.Add(this.lblFietsentotaleprijs);
            this.tabPage2.Controls.Add(this.btnT2volgende);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(449, 435);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Fietsen";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(66, 389);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 13);
            this.label15.TabIndex = 20;
            this.label15.Text = "in euros";
            // 
            // btnFietsklaar
            // 
            this.btnFietsklaar.Location = new System.Drawing.Point(20, 326);
            this.btnFietsklaar.Name = "btnFietsklaar";
            this.btnFietsklaar.Size = new System.Drawing.Size(391, 24);
            this.btnFietsklaar.TabIndex = 19;
            this.btnFietsklaar.Text = "Klaar met kiezen";
            this.btnFietsklaar.UseVisualStyleBackColor = true;
            this.btnFietsklaar.Click += new System.EventHandler(this.btnFietsklaar_Click);
            // 
            // lblFietsentotaleprijs
            // 
            this.lblFietsentotaleprijs.AutoSize = true;
            this.lblFietsentotaleprijs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.lblFietsentotaleprijs.Location = new System.Drawing.Point(27, 366);
            this.lblFietsentotaleprijs.Name = "lblFietsentotaleprijs";
            this.lblFietsentotaleprijs.Size = new System.Drawing.Size(124, 18);
            this.lblFietsentotaleprijs.TabIndex = 18;
            this.lblFietsentotaleprijs.Text = "Totale Prijs: 0,-";
            // 
            // btnT2volgende
            // 
            this.btnT2volgende.Location = new System.Drawing.Point(316, 398);
            this.btnT2volgende.Name = "btnT2volgende";
            this.btnT2volgende.Size = new System.Drawing.Size(118, 27);
            this.btnT2volgende.TabIndex = 16;
            this.btnT2volgende.Text = "Accessoires";
            this.btnT2volgende.UseVisualStyleBackColor = true;
            this.btnT2volgende.Click += new System.EventHandler(this.btnT2volgende_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.nudFiets4aantal);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.nudFiets4dagen);
            this.groupBox3.Controls.Add(this.chkFiets4);
            this.groupBox3.Location = new System.Drawing.Point(231, 160);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(180, 160);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label12.Location = new System.Drawing.Point(12, 69);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "Aantal";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label8.Location = new System.Drawing.Point(10, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Dagen";
            // 
            // nudFiets4aantal
            // 
            this.nudFiets4aantal.Location = new System.Drawing.Point(13, 85);
            this.nudFiets4aantal.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudFiets4aantal.Name = "nudFiets4aantal";
            this.nudFiets4aantal.Size = new System.Drawing.Size(153, 20);
            this.nudFiets4aantal.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "30,- euro per Dag";
            // 
            // nudFiets4dagen
            // 
            this.nudFiets4dagen.Location = new System.Drawing.Point(13, 124);
            this.nudFiets4dagen.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.nudFiets4dagen.Name = "nudFiets4dagen";
            this.nudFiets4dagen.Size = new System.Drawing.Size(153, 20);
            this.nudFiets4dagen.TabIndex = 1;
            // 
            // chkFiets4
            // 
            this.chkFiets4.AutoSize = true;
            this.chkFiets4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkFiets4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chkFiets4.Location = new System.Drawing.Point(13, 19);
            this.chkFiets4.Name = "chkFiets4";
            this.chkFiets4.Size = new System.Drawing.Size(123, 17);
            this.chkFiets4.TabIndex = 0;
            this.chkFiets4.Text = "4. Bamboo BeFun";
            this.chkFiets4.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.nudFiets2aantal);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.nudFiets2dagen);
            this.groupBox2.Controls.Add(this.chkFiets2);
            this.groupBox2.Location = new System.Drawing.Point(231, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(180, 157);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label14.Location = new System.Drawing.Point(12, 72);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 13);
            this.label14.TabIndex = 23;
            this.label14.Text = "Aantal";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label10.Location = new System.Drawing.Point(10, 111);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Dagen";
            // 
            // nudFiets2aantal
            // 
            this.nudFiets2aantal.Location = new System.Drawing.Point(13, 88);
            this.nudFiets2aantal.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudFiets2aantal.Name = "nudFiets2aantal";
            this.nudFiets2aantal.Size = new System.Drawing.Size(153, 20);
            this.nudFiets2aantal.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "110,- euro per Dag";
            // 
            // nudFiets2dagen
            // 
            this.nudFiets2dagen.Location = new System.Drawing.Point(13, 128);
            this.nudFiets2dagen.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.nudFiets2dagen.Name = "nudFiets2dagen";
            this.nudFiets2dagen.Size = new System.Drawing.Size(153, 20);
            this.nudFiets2dagen.TabIndex = 1;
            // 
            // chkFiets2
            // 
            this.chkFiets2.AutoSize = true;
            this.chkFiets2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chkFiets2.Location = new System.Drawing.Point(13, 19);
            this.chkFiets2.Name = "chkFiets2";
            this.chkFiets2.Size = new System.Drawing.Size(158, 17);
            this.chkFiets2.TabIndex = 0;
            this.chkFiets2.Text = "2. Bamboo BF DELUXE";
            this.chkFiets2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.nudFiets3aantal);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.nudFiets3dagen);
            this.groupBox4.Controls.Add(this.chkFiets3);
            this.groupBox4.Location = new System.Drawing.Point(20, 160);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(180, 160);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label13.Location = new System.Drawing.Point(12, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "Aantal";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label9.Location = new System.Drawing.Point(10, 108);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Dagen";
            // 
            // nudFiets3aantal
            // 
            this.nudFiets3aantal.Location = new System.Drawing.Point(13, 85);
            this.nudFiets3aantal.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudFiets3aantal.Name = "nudFiets3aantal";
            this.nudFiets3aantal.Size = new System.Drawing.Size(153, 20);
            this.nudFiets3aantal.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "90,- euro per Dag";
            // 
            // nudFiets3dagen
            // 
            this.nudFiets3dagen.Location = new System.Drawing.Point(13, 126);
            this.nudFiets3dagen.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.nudFiets3dagen.Name = "nudFiets3dagen";
            this.nudFiets3dagen.Size = new System.Drawing.Size(153, 20);
            this.nudFiets3dagen.TabIndex = 1;
            // 
            // chkFiets3
            // 
            this.chkFiets3.AutoSize = true;
            this.chkFiets3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chkFiets3.Location = new System.Drawing.Point(13, 19);
            this.chkFiets3.Name = "chkFiets3";
            this.chkFiets3.Size = new System.Drawing.Size(148, 17);
            this.chkFiets3.TabIndex = 0;
            this.chkFiets3.Text = "3. Bamboo BF Cruiser";
            this.chkFiets3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.nudFiets1aantal);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.nudFiets1dagen);
            this.groupBox1.Controls.Add(this.chkFiets1);
            this.groupBox1.Location = new System.Drawing.Point(20, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(180, 157);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.toolTip2.SetToolTip(this.groupBox1, "Probleeeeeem");
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label11.Location = new System.Drawing.Point(12, 72);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Aantal";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label7.Location = new System.Drawing.Point(10, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Dagen";
            // 
            // nudFiets1aantal
            // 
            this.nudFiets1aantal.Location = new System.Drawing.Point(13, 88);
            this.nudFiets1aantal.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudFiets1aantal.Name = "nudFiets1aantal";
            this.nudFiets1aantal.Size = new System.Drawing.Size(153, 20);
            this.nudFiets1aantal.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "60,- euro per Dag";
            // 
            // nudFiets1dagen
            // 
            this.nudFiets1dagen.Location = new System.Drawing.Point(13, 128);
            this.nudFiets1dagen.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.nudFiets1dagen.Name = "nudFiets1dagen";
            this.nudFiets1dagen.Size = new System.Drawing.Size(153, 20);
            this.nudFiets1dagen.TabIndex = 1;
            // 
            // chkFiets1
            // 
            this.chkFiets1.AutoSize = true;
            this.chkFiets1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chkFiets1.Location = new System.Drawing.Point(7, 19);
            this.chkFiets1.Name = "chkFiets1";
            this.chkFiets1.Size = new System.Drawing.Size(167, 17);
            this.chkFiets1.TabIndex = 0;
            this.chkFiets1.Text = "1. Bamboo BF Standaard";
            this.chkFiets1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.lbTotPrijsAcc);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.btnAccKlaar);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.btnT3Volgende);
            this.tabPage3.Controls.Add(this.btnT3Vorige);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(449, 435);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Accessoires";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(59, 377);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "in euro\'s";
            // 
            // lbTotPrijsAcc
            // 
            this.lbTotPrijsAcc.AutoSize = true;
            this.lbTotPrijsAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.lbTotPrijsAcc.Location = new System.Drawing.Point(23, 357);
            this.lbTotPrijsAcc.Name = "lbTotPrijsAcc";
            this.lbTotPrijsAcc.Size = new System.Drawing.Size(124, 18);
            this.lbTotPrijsAcc.TabIndex = 7;
            this.lbTotPrijsAcc.Text = "Totale Prijs: 0,-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "label6";
            // 
            // btnAccKlaar
            // 
            this.btnAccKlaar.Location = new System.Drawing.Point(17, 329);
            this.btnAccKlaar.Name = "btnAccKlaar";
            this.btnAccKlaar.Size = new System.Drawing.Size(406, 25);
            this.btnAccKlaar.TabIndex = 5;
            this.btnAccKlaar.Text = "Klaar met kiezen";
            this.btnAccKlaar.UseVisualStyleBackColor = true;
            this.btnAccKlaar.Click += new System.EventHandler(this.btnAccKlaar_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.chbExtr2);
            this.groupBox7.Controls.Add(this.nudExtr2);
            this.groupBox7.Controls.Add(this.chbExtr1);
            this.groupBox7.Controls.Add(this.nudExtr1);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.groupBox7.Location = new System.Drawing.Point(17, 226);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(406, 96);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Extra\'s: 1,- euro per stuk";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label19.Location = new System.Drawing.Point(7, 52);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 15);
            this.label19.TabIndex = 9;
            this.label19.Text = "Aantal";
            // 
            // chbExtr2
            // 
            this.chbExtr2.AutoSize = true;
            this.chbExtr2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chbExtr2.Location = new System.Drawing.Point(200, 29);
            this.chbExtr2.Name = "chbExtr2";
            this.chbExtr2.Size = new System.Drawing.Size(48, 17);
            this.chbExtr2.TabIndex = 8;
            this.chbExtr2.Text = "Flyer";
            this.chbExtr2.UseVisualStyleBackColor = true;
            // 
            // nudExtr2
            // 
            this.nudExtr2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nudExtr2.Location = new System.Drawing.Point(201, 52);
            this.nudExtr2.Name = "nudExtr2";
            this.nudExtr2.Size = new System.Drawing.Size(51, 20);
            this.nudExtr2.TabIndex = 10;
            // 
            // chbExtr1
            // 
            this.chbExtr1.AutoSize = true;
            this.chbExtr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chbExtr1.Location = new System.Drawing.Point(92, 29);
            this.chbExtr1.Name = "chbExtr1";
            this.chbExtr1.Size = new System.Drawing.Size(83, 17);
            this.chbExtr1.TabIndex = 6;
            this.chbExtr1.Text = "Bakfiets Pet";
            this.chbExtr1.UseVisualStyleBackColor = true;
            // 
            // nudExtr1
            // 
            this.nudExtr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nudExtr1.Location = new System.Drawing.Point(114, 52);
            this.nudExtr1.Name = "nudExtr1";
            this.nudExtr1.Size = new System.Drawing.Size(51, 20);
            this.nudExtr1.TabIndex = 9;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.nudAcc3);
            this.groupBox6.Controls.Add(this.chbAcc2);
            this.groupBox6.Controls.Add(this.nudAcc2);
            this.groupBox6.Controls.Add(this.chbAcc1);
            this.groupBox6.Controls.Add(this.nudAcc1);
            this.groupBox6.Controls.Add(this.chbAcc3);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.groupBox6.Location = new System.Drawing.Point(17, 126);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(406, 103);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Fiets accessoires: 15,- per stuk";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label18.Location = new System.Drawing.Point(6, 68);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 15);
            this.label18.TabIndex = 7;
            this.label18.Text = "Aantal";
            // 
            // nudAcc3
            // 
            this.nudAcc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nudAcc3.Location = new System.Drawing.Point(299, 68);
            this.nudAcc3.Name = "nudAcc3";
            this.nudAcc3.Size = new System.Drawing.Size(51, 20);
            this.nudAcc3.TabIndex = 8;
            // 
            // chbAcc2
            // 
            this.chbAcc2.AutoSize = true;
            this.chbAcc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chbAcc2.Location = new System.Drawing.Point(174, 33);
            this.chbAcc2.Name = "chbAcc2";
            this.chbAcc2.Size = new System.Drawing.Size(101, 17);
            this.chbAcc2.TabIndex = 5;
            this.chbAcc2.Text = "Telefoonhouder";
            this.chbAcc2.UseVisualStyleBackColor = true;
            // 
            // nudAcc2
            // 
            this.nudAcc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nudAcc2.Location = new System.Drawing.Point(200, 68);
            this.nudAcc2.Name = "nudAcc2";
            this.nudAcc2.Size = new System.Drawing.Size(51, 20);
            this.nudAcc2.TabIndex = 7;
            // 
            // chbAcc1
            // 
            this.chbAcc1.AutoSize = true;
            this.chbAcc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chbAcc1.Location = new System.Drawing.Point(63, 33);
            this.chbAcc1.Name = "chbAcc1";
            this.chbAcc1.Size = new System.Drawing.Size(91, 17);
            this.chbAcc1.TabIndex = 3;
            this.chbAcc1.Text = "Zonnescherm";
            this.chbAcc1.UseVisualStyleBackColor = true;
            // 
            // nudAcc1
            // 
            this.nudAcc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nudAcc1.Location = new System.Drawing.Point(92, 68);
            this.nudAcc1.Name = "nudAcc1";
            this.nudAcc1.Size = new System.Drawing.Size(51, 20);
            this.nudAcc1.TabIndex = 6;
            // 
            // chbAcc3
            // 
            this.chbAcc3.AutoSize = true;
            this.chbAcc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chbAcc3.Location = new System.Drawing.Point(299, 33);
            this.chbAcc3.Name = "chbAcc3";
            this.chbAcc3.Size = new System.Drawing.Size(66, 17);
            this.chbAcc3.TabIndex = 4;
            this.chbAcc3.Text = "Speaker";
            this.chbAcc3.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.nudHelmL);
            this.groupBox5.Controls.Add(this.nudHelmM);
            this.groupBox5.Controls.Add(this.nudHelmS);
            this.groupBox5.Controls.Add(this.chbBesHelmM);
            this.groupBox5.Controls.Add(this.chbBesHelmL);
            this.groupBox5.Controls.Add(this.chbBesHelmS);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.groupBox5.Location = new System.Drawing.Point(17, 17);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(406, 123);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Bescherming: 20,- euro per stuk";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.label17.Location = new System.Drawing.Point(7, 69);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 15);
            this.label17.TabIndex = 6;
            this.label17.Text = "Aantal";
            // 
            // nudHelmL
            // 
            this.nudHelmL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nudHelmL.Location = new System.Drawing.Point(299, 69);
            this.nudHelmL.Name = "nudHelmL";
            this.nudHelmL.Size = new System.Drawing.Size(51, 20);
            this.nudHelmL.TabIndex = 5;
            // 
            // nudHelmM
            // 
            this.nudHelmM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nudHelmM.Location = new System.Drawing.Point(195, 69);
            this.nudHelmM.Name = "nudHelmM";
            this.nudHelmM.Size = new System.Drawing.Size(51, 20);
            this.nudHelmM.TabIndex = 4;
            // 
            // nudHelmS
            // 
            this.nudHelmS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.nudHelmS.Location = new System.Drawing.Point(83, 69);
            this.nudHelmS.Name = "nudHelmS";
            this.nudHelmS.Size = new System.Drawing.Size(51, 20);
            this.nudHelmS.TabIndex = 3;
            // 
            // chbBesHelmM
            // 
            this.chbBesHelmM.AutoSize = true;
            this.chbBesHelmM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chbBesHelmM.Location = new System.Drawing.Point(177, 37);
            this.chbBesHelmM.Name = "chbBesHelmM";
            this.chbBesHelmM.Size = new System.Drawing.Size(62, 17);
            this.chbBesHelmM.TabIndex = 2;
            this.chbBesHelmM.Text = "Helm M";
            this.chbBesHelmM.UseVisualStyleBackColor = true;
            // 
            // chbBesHelmL
            // 
            this.chbBesHelmL.AutoSize = true;
            this.chbBesHelmL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chbBesHelmL.Location = new System.Drawing.Point(292, 37);
            this.chbBesHelmL.Name = "chbBesHelmL";
            this.chbBesHelmL.Size = new System.Drawing.Size(59, 17);
            this.chbBesHelmL.TabIndex = 1;
            this.chbBesHelmL.Text = "Helm L";
            this.chbBesHelmL.UseVisualStyleBackColor = true;
            // 
            // chbBesHelmS
            // 
            this.chbBesHelmS.AutoSize = true;
            this.chbBesHelmS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.chbBesHelmS.Location = new System.Drawing.Point(67, 37);
            this.chbBesHelmS.Name = "chbBesHelmS";
            this.chbBesHelmS.Size = new System.Drawing.Size(60, 17);
            this.chbBesHelmS.TabIndex = 0;
            this.chbBesHelmS.Text = "Helm S";
            this.chbBesHelmS.UseVisualStyleBackColor = true;
            // 
            // btnT3Volgende
            // 
            this.btnT3Volgende.Location = new System.Drawing.Point(296, 399);
            this.btnT3Volgende.Name = "btnT3Volgende";
            this.btnT3Volgende.Size = new System.Drawing.Size(137, 24);
            this.btnT3Volgende.TabIndex = 1;
            this.btnT3Volgende.Text = "Betalen";
            this.btnT3Volgende.UseVisualStyleBackColor = true;
            this.btnT3Volgende.Click += new System.EventHandler(this.btnT3Volgende_Click);
            // 
            // btnT3Vorige
            // 
            this.btnT3Vorige.Location = new System.Drawing.Point(14, 399);
            this.btnT3Vorige.Name = "btnT3Vorige";
            this.btnT3Vorige.Size = new System.Drawing.Size(137, 24);
            this.btnT3Vorige.TabIndex = 0;
            this.btnT3Vorige.Text = "Fietsen";
            this.btnT3Vorige.UseVisualStyleBackColor = true;
            this.btnT3Vorige.Click += new System.EventHandler(this.btnT3Vorige_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.lstOverzicht);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.btnKortingtoevoegen);
            this.tabPage4.Controls.Add(this.groupBox8);
            this.tabPage4.Controls.Add(this.btnBetalen);
            this.tabPage4.Controls.Add(this.btnT4Terug);
            this.tabPage4.Controls.Add(this.lbBetalenTotaleprijs);
            this.tabPage4.Controls.Add(this.tbKortingscode);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(449, 435);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Betalen";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // lstOverzicht
            // 
            this.lstOverzicht.BackColor = System.Drawing.SystemColors.Window;
            this.lstOverzicht.FormattingEnabled = true;
            this.lstOverzicht.Location = new System.Drawing.Point(23, 34);
            this.lstOverzicht.Name = "lstOverzicht";
            this.lstOverzicht.Size = new System.Drawing.Size(394, 121);
            this.lstOverzicht.TabIndex = 10;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(281, 227);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 13);
            this.label21.TabIndex = 9;
            this.label21.Text = "KORTING";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(59, 240);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 13);
            this.label20.TabIndex = 7;
            this.label20.Text = "in euro\'s";
            // 
            // btnKortingtoevoegen
            // 
            this.btnKortingtoevoegen.Location = new System.Drawing.Point(23, 183);
            this.btnKortingtoevoegen.Name = "btnKortingtoevoegen";
            this.btnKortingtoevoegen.Size = new System.Drawing.Size(394, 26);
            this.btnKortingtoevoegen.TabIndex = 6;
            this.btnKortingtoevoegen.Text = "Kortingscode toevoegen";
            this.btnKortingtoevoegen.UseVisualStyleBackColor = true;
            this.btnKortingtoevoegen.Click += new System.EventHandler(this.btnKortingtoevoegen_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.rdoKlerna);
            this.groupBox8.Controls.Add(this.rdoVisa);
            this.groupBox8.Controls.Add(this.rdoContant);
            this.groupBox8.Controls.Add(this.rdoIDeal);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.groupBox8.Location = new System.Drawing.Point(23, 274);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(394, 84);
            this.groupBox8.TabIndex = 5;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Betaalwijze";
            // 
            // rdoKlerna
            // 
            this.rdoKlerna.AutoSize = true;
            this.rdoKlerna.Location = new System.Drawing.Point(144, 51);
            this.rdoKlerna.Name = "rdoKlerna";
            this.rdoKlerna.Size = new System.Drawing.Size(55, 17);
            this.rdoKlerna.TabIndex = 3;
            this.rdoKlerna.TabStop = true;
            this.rdoKlerna.Text = "Klerna";
            this.rdoKlerna.UseVisualStyleBackColor = true;
            // 
            // rdoVisa
            // 
            this.rdoVisa.AutoSize = true;
            this.rdoVisa.Location = new System.Drawing.Point(7, 50);
            this.rdoVisa.Name = "rdoVisa";
            this.rdoVisa.Size = new System.Drawing.Size(109, 17);
            this.rdoVisa.TabIndex = 2;
            this.rdoVisa.TabStop = true;
            this.rdoVisa.Text = "Mastercard / Visa";
            this.rdoVisa.UseVisualStyleBackColor = true;
            // 
            // rdoContant
            // 
            this.rdoContant.AutoSize = true;
            this.rdoContant.Location = new System.Drawing.Point(144, 19);
            this.rdoContant.Name = "rdoContant";
            this.rdoContant.Size = new System.Drawing.Size(97, 17);
            this.rdoContant.TabIndex = 1;
            this.rdoContant.TabStop = true;
            this.rdoContant.Text = "Contant / Cash";
            this.rdoContant.UseVisualStyleBackColor = true;
            // 
            // rdoIDeal
            // 
            this.rdoIDeal.AutoSize = true;
            this.rdoIDeal.Location = new System.Drawing.Point(7, 19);
            this.rdoIDeal.Name = "rdoIDeal";
            this.rdoIDeal.Size = new System.Drawing.Size(49, 17);
            this.rdoIDeal.TabIndex = 0;
            this.rdoIDeal.TabStop = true;
            this.rdoIDeal.Text = "iDeal";
            this.rdoIDeal.UseVisualStyleBackColor = true;
            // 
            // btnBetalen
            // 
            this.btnBetalen.Location = new System.Drawing.Point(23, 397);
            this.btnBetalen.Name = "btnBetalen";
            this.btnBetalen.Size = new System.Drawing.Size(394, 23);
            this.btnBetalen.TabIndex = 4;
            this.btnBetalen.Text = "Betalen / reserveren";
            this.btnBetalen.UseVisualStyleBackColor = true;
            this.btnBetalen.Click += new System.EventHandler(this.btnBetalen_Click);
            // 
            // btnT4Terug
            // 
            this.btnT4Terug.Location = new System.Drawing.Point(23, 364);
            this.btnT4Terug.Name = "btnT4Terug";
            this.btnT4Terug.Size = new System.Drawing.Size(394, 23);
            this.btnT4Terug.TabIndex = 3;
            this.btnT4Terug.Text = "Bestelling aanpassen";
            this.btnT4Terug.UseVisualStyleBackColor = true;
            this.btnT4Terug.Click += new System.EventHandler(this.btnT4Terug_Click);
            // 
            // lbBetalenTotaleprijs
            // 
            this.lbBetalenTotaleprijs.AutoSize = true;
            this.lbBetalenTotaleprijs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.lbBetalenTotaleprijs.Location = new System.Drawing.Point(20, 222);
            this.lbBetalenTotaleprijs.Name = "lbBetalenTotaleprijs";
            this.lbBetalenTotaleprijs.Size = new System.Drawing.Size(124, 18);
            this.lbBetalenTotaleprijs.TabIndex = 2;
            this.lbBetalenTotaleprijs.Text = "Totale Prijs: 0,-";
            // 
            // tbKortingscode
            // 
            this.tbKortingscode.Location = new System.Drawing.Point(23, 157);
            this.tbKortingscode.Name = "tbKortingscode";
            this.tbKortingscode.Size = new System.Drawing.Size(394, 20);
            this.tbKortingscode.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(20, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Overzicht producten ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 478);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets4aantal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets4dagen)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets2aantal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets2dagen)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets3aantal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets3dagen)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets1aantal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFiets1dagen)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudExtr2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudExtr1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAcc3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAcc2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAcc1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudHelmL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHelmM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHelmS)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown nudFiets4dagen;
        private System.Windows.Forms.CheckBox chkFiets4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown nudFiets2dagen;
        private System.Windows.Forms.CheckBox chkFiets2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown nudFiets3dagen;
        private System.Windows.Forms.CheckBox chkFiets3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nudFiets1dagen;
        private System.Windows.Forms.CheckBox chkFiets1;
        private System.Windows.Forms.Button btnT2volgende;
        private System.Windows.Forms.Button btnT3Volgende;
        private System.Windows.Forms.Button btnT3Vorige;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblFietsentotaleprijs;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lbBetalenTotaleprijs;
        private System.Windows.Forms.TextBox tbKortingscode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudFiets1aantal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nudFiets4aantal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nudFiets2aantal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown nudFiets3aantal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnFietsklaar;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chbExtr2;
        private System.Windows.Forms.NumericUpDown nudExtr2;
        private System.Windows.Forms.CheckBox chbExtr1;
        private System.Windows.Forms.NumericUpDown nudExtr1;
        private System.Windows.Forms.NumericUpDown nudAcc3;
        private System.Windows.Forms.CheckBox chbAcc2;
        private System.Windows.Forms.NumericUpDown nudAcc2;
        private System.Windows.Forms.CheckBox chbAcc1;
        private System.Windows.Forms.NumericUpDown nudAcc1;
        private System.Windows.Forms.CheckBox chbAcc3;
        private System.Windows.Forms.NumericUpDown nudHelmL;
        private System.Windows.Forms.NumericUpDown nudHelmM;
        private System.Windows.Forms.NumericUpDown nudHelmS;
        private System.Windows.Forms.CheckBox chbBesHelmM;
        private System.Windows.Forms.CheckBox chbBesHelmL;
        private System.Windows.Forms.CheckBox chbBesHelmS;
        private System.Windows.Forms.Button btnAccKlaar;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbTotPrijsAcc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnKortingtoevoegen;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton rdoKlerna;
        private System.Windows.Forms.RadioButton rdoVisa;
        private System.Windows.Forms.RadioButton rdoContant;
        private System.Windows.Forms.RadioButton rdoIDeal;
        private System.Windows.Forms.Button btnBetalen;
        private System.Windows.Forms.Button btnT4Terug;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ListBox lstOverzicht;
        private System.Windows.Forms.Button btT1Begin;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
    }
}

